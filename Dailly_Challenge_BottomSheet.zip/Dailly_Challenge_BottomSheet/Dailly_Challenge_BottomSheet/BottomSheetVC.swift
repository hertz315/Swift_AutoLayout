//
//  BottomSheetVC.swift
//  Dailly_Challenge_BottomSheet
//
//  Created by Hertz on 9/18/22.
//

import UIKit
import PanModal
import WebKit

class BottomSheetVC: UIViewController, WKUIDelegate {
    
    static let identifier = "BottomSheetVC"
    
    // MARK: - 전역 변수
    let data: BottomSheetModel = BottomSheetModel(title: "🎉 빡코딩 레스토랑 200주년 이벤트 ",
                                                  image: UIImage(named: "bottomSheetImage")!,
                                                  leftButtonLabel: "never 보지 않기",
                                                  rightBattonLabel: "30시간 보지 않기")
    var webView: WKWebView!
    
    
    // MARK: - @IBOutlet
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var mainImage: UIImageView!
    @IBOutlet weak var neverSeeAgainButton: UIButton!
    @IBOutlet weak var doNotWatchFor24Hours: UIButton!
    
    // MARK: - loadView - LifeCycle
    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        view = webView
    }
    
    // MARK: - viewDidLoad - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        makeUI()
        bottomSheetImageTapped()
        
    }
    
    func makeUI() {
        self.titleLabel.text = data.title
        self.mainImage.image = data.image
        self.neverSeeAgainButton.setTitle(data.leftButtonLabel, for: .normal)
        self.doNotWatchFor24Hours.setTitle(data.rightBattonLabel, for: .normal)
    }
    
    func webViewRequest() {
        let myURL = URL(string:"https://www.apple.com")
        let myRequest = URLRequest(url: myURL!)
        webView.load(myRequest)
    }
    
    func bottomSheetImageTapped() {
        let imageTapped = UITapGestureRecognizer(target: self, action: #selector(tapImage))
        mainImage.addGestureRecognizer(imageTapped)
        mainImage.isUserInteractionEnabled = true
    }
    
    @objc func tapImage(sender: UITapGestureRecognizer) {
        print("⭐️")
        
        
    }
    
    // MARK: - @IBAction
    @IBAction func neverSeeAgainButtonTapped(_ sender: UIButton) {
        
    }
    
    @IBAction func doNotWatchFor24HoursButtonTapped(_ sender: UIButton) {
        
    }
    
    
}


extension BottomSheetVC: PanModalPresentable {
    // 스크롤되는 tableview 나 collectionview 가 있다면 여기에 넣어주면 PanModal 이 모달과 스크롤 뷰 사이에서 팬 제스처를 원활하게 전환합니다.
    var panScrollable: UIScrollView? {
        return nil
    }
    
    var shortFormHeight: PanModalHeight {
        return .contentHeight(UIScreen.main.bounds.height / 2)
    }
    
    var cornerRadius: CGFloat {
        return 15
    }
    
    var longFormHeight: PanModalHeight {
        return .maxHeightWithTopInset(0)
    }
    
}

