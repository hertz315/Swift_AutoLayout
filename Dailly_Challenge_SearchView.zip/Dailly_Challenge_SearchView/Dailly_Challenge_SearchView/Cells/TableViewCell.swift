//
//  TableViewCell.swift
//  Dailly_Challenge_SearchView
//
//  Created by Hertz on 9/14/22.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    static let identifier = "TableViewCell"
    
    @IBOutlet weak var popularSearchTermButton: UIButton!
    
    var mainVC = ViewController()
    
    var popularSearchTermText: String?
    
    
    
    var popularSearchTermButtonText: String = "" {
        didSet {
            popularSearchTermButton.setTitle(popularSearchTermButtonText, for: .normal)
            self.popularSearchTermText
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for. the selected state
    }
    
    @IBAction func popularSearchTermButtonTapped(_ sender: UIButton) {
    }
    
    
}
