//
//  PopularTermsDataManager.swift
//  Dailly_Challenge_SearchView
//
//  Created by Hertz on 9/14/22.
//

import Foundation

struct PopularTermsDataManager {
    
    static func makePopularTerms() -> [PopularTerms] {
        let data: [PopularTerms] = [
            PopularTerms(title: "빡코딩"),
            PopularTerms(title: "오늘도 빡코딩"),
            PopularTerms(title: "버거킹"),
            PopularTerms(title: "오므라이스"),
            PopularTerms(title: "핫도그"),
            PopularTerms(title: "아이스크림"),
            PopularTerms(title: "치즈"),
            PopularTerms(title: "빡코딩"),
            PopularTerms(title: "빡코딩"),
            PopularTerms(title: "오늘도 빡코딩"),
            PopularTerms(title: "버거킹"),
            PopularTerms(title: "오므라이스"),
            PopularTerms(title: "핫도그"),
            PopularTerms(title: "아이스크림"),
            PopularTerms(title: "치즈"),
            PopularTerms(title: "빡코딩"),
            PopularTerms(title: "빡코딩"),
            PopularTerms(title: "오늘도 빡코딩"),
            PopularTerms(title: "버거킹"),
            PopularTerms(title: "오므라이스"),
            PopularTerms(title: "핫도그"),
            PopularTerms(title: "아이스크림"),
            PopularTerms(title: "치즈"),
            PopularTerms(title: "빡코딩"),
        ]
        
        return data
    }
    
}
