//
//  PopularTerms.swift
//  Dailly_Challenge_SearchView
//
//  Created by Hertz on 9/14/22.
//

import Foundation

struct PopularTerms {
    var title: String
}

