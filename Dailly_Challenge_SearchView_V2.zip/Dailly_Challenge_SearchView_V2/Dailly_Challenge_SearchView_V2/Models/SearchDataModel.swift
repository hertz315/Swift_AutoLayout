//
//  SearchDataModel.swift
//  Dailly_Challenge_SearchView_V2
//
//  Created by Hertz on 9/17/22.
//

import Foundation

struct SearchDataModel: Hashable {
    var mainTitle: String?
}
